
import json
import pyperclip

def save_to_json(payloads, filename):
    with open(filename, "w") as f:
        json.dump(payloads, f, indent=4)
    print(f"Saved to {filename}")

def copy_to_clipboard(payloads):
    pyperclip.copy("\n".join(payloads))
    print("Copied to clipboard!")
