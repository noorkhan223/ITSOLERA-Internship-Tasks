
def obfuscate(payload):
    return payload.replace(" ", "/**/").replace("script", "scr<!-- -->ipt")
