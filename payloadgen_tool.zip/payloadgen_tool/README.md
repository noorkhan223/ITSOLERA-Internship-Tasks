
# Custom Payload Generator for Web Exploitation

This tool generates payloads for XSS, SQL Injection, and Command Injection with optional encoding, obfuscation, and export options.

## Usage
```bash
python main.py --xss
python main.py --sqli --encode=url
python main.py --cmd --encode=base64 --obfuscate --output=json
```

## Features
- XSS (Reflected, Stored, DOM-based)
- SQLi (Error-based, Union-based, Blind)
- Command Injection (Linux/Windows)
- Encoding (Base64, URL, Hex, Unicode)
- Obfuscation
- Export to JSON or copy to clipboard

## Requirements
- Python 3.x
- pyperclip (`pip install pyperclip`)
