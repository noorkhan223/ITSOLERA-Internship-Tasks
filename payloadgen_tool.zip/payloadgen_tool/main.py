import argparse
from modules import xss, sqli, cmd
from utils import encoder, obfuscator, output

def main():
    parser = argparse.ArgumentParser(description="Custom Payload Generator for Web Exploitation")
    parser.add_argument("--xss", action="store_true", help="Generate XSS payloads")
    parser.add_argument("--sqli", action="store_true", help="Generate SQLi payloads")
    parser.add_argument("--cmd", action="store_true", help="Generate Command Injection payloads")
    parser.add_argument("--encode", choices=["base64", "url", "hex", "unicode"], help="Encode the payloads")
    parser.add_argument("--obfuscate", action="store_true", help="Obfuscate the payloads")
    parser.add_argument("--no-encode", action="store_true", help="Skip encoding even if --encode is set")
    parser.add_argument("--output", choices=["json", "clipboard"], help="Export method")

    args = parser.parse_args()
    payloads = []

    # Step 1: Select payload type
    if args.xss:
        payloads = xss.get_payloads()
    elif args.sqli:
        payloads = sqli.get_payloads()
    elif args.cmd:
        payloads = cmd.get_payloads()

    # Step 2: Obfuscate if requested
    if args.obfuscate:
        payloads = [obfuscator.obfuscate(p) for p in payloads]

    # Step 3: Encode if requested and not skipped
    if args.encode and not args.no_encode:
        payloads = [encoder.encode(p, args.encode) for p in payloads]

    # Step 4: Output handling
    if args.output == "json":
        output.save_to_json(payloads, "output_payloads.json")
    elif args.output == "clipboard":
        output.copy_to_clipboard(payloads)
    else:
        for p in payloads:
            print(p)

if __name__ == "__main__":
    main()
