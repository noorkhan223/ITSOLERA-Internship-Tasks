#!/bin/sh
echo "Content-Type: text/plain"
echo
echo "Hello from CGI!"
/usr/bin/id
