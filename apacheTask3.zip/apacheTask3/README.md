# CVE-2021-41773 Exploit Lab (Apache 2.4.49)

## 📌 About
This project replicates **CVE-2021-41773** vulnerability in **Apache HTTP Server 2.4.49** inside Docker.  
The vulnerability allows **Path Traversal** and, if CGI is enabled, **Remote Code Execution (RCE)**.

---

## ⚙️ Lab Setup
### Requirements
- Docker Desktop
- Python 3
- curl (already inside Windows as `curl.exe`)
- VS Code (optional)

### Files
- `Dockerfile` → builds Apache 2.4.49 with CGI enabled  
- `httpd.conf` → Apache configuration (CGI enabled)  
- `index.html` → test page  
- `cgi-bin/hello.sh` → CGI test script  
- `exploit.py` → exploit PoC  

---

## ▶️ Build & Run
```bash
docker build -t apache-2.4.49 .
docker run -dit --name apache-cve -p 8080:80 apache-2.4.49
